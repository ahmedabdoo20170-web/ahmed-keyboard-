package com.trio.keyboard

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Button
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = getSharedPreferences("trio_kb", MODE_PRIVATE)

        findViewById<Button>(R.id.btnOpenIME).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        val cards = mapOf(
            "samsung" to findViewById<LinearLayout>(R.id.cardSamsung),
            "google" to findViewById<LinearLayout>(R.id.cardGoogle),
            "iphone" to findViewById<LinearLayout>(R.id.cardIphone)
        )

        fun select(name: String) {
            prefs.edit().putString("theme", name).apply()
            cards.forEach { (k, v) -> styleCard(v, k == name) }
            Toast.makeText(this, "تم اختيار شكل ${when(name){"samsung"->"سامسونج";"google"->"جوجل";else->"آيفون"}}", Toast.LENGTH_SHORT).show()
        }

        cards.forEach { (name, card) -> card.setOnClickListener { select(name) } }
        styleCard(cards[prefs.getString("theme", "samsung")]!!, true)

        val sbHeight = findViewById<SeekBar>(R.id.sbHeight)
        val tvHeight = findViewById<TextView>(R.id.tvHeight)
        val sbFont = findViewById<SeekBar>(R.id.sbFont)
        val tvFont = findViewById<TextView>(R.id.tvFont)
        val swSound = findViewById<Switch>(R.id.swSound)
        val swVib = findViewById<Switch>(R.id.swVib)

        sbHeight.progress = prefs.getInt("height", 100)
        tvHeight.text = "${sbHeight.progress}%"
        sbFont.progress = prefs.getInt("font", 100)
        tvFont.text = "${sbFont.progress}%"
        swSound.isChecked = prefs.getBoolean("sound", true)
        swVib.isChecked = prefs.getBoolean("vib", true)

        sbHeight.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                tvHeight.text = "$p%"
                prefs.edit().putInt("height", p).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        sbFont.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                tvFont.text = "$p%"
                prefs.edit().putInt("font", p).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        swSound.setOnCheckedChangeListener { _, b -> prefs.edit().putBoolean("sound", b).apply() }
        swVib.setOnCheckedChangeListener { _, b -> prefs.edit().putBoolean("vib", b).apply() }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            prefs.edit().clear().apply()
            sbHeight.progress = 100; tvHeight.text = "100%"
            sbFont.progress = 100; tvFont.text = "100%"
            swSound.isChecked = true; swVib.isChecked = true
            select("samsung")
            Toast.makeText(this, "تمت إعادة الضبط", Toast.LENGTH_SHORT).show()
        }
    }

    private fun styleCard(card: LinearLayout, selected: Boolean) {
        val bg = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = 24f
            setStroke(
                if (selected) 6 else 2,
                if (selected) Color.parseColor("#1F2126") else Color.parseColor("#DDE1E6")
            )
        }
        card.background = bg
        card.elevation = if (selected) 8f else 2f
    }
}
