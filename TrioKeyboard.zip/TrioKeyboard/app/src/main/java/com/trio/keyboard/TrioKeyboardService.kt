package com.trio.keyboard

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

class TrioKeyboardService : InputMethodService() {

    private lateinit var root: LinearLayout
    private lateinit var prefs: SharedPreferences

    private var arabic = true
    private var symbols = false
    private var caps = false

    private var theme = "samsung"
    private var heightScale = 1.0f
    private var fontScale = 1.0f
    private var soundOn = true
    private var vibOn = true

    private val AR_ROWS = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح"),
        listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك"),
        listOf("ط", "ئ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ظ")
    )
    private val EN_ROWS = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )
    private val SYM_ROWS = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")"),
        listOf("*", "!", "?", "/", ":", ";", ".", ",")
    )

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("trio_kb", Context.MODE_PRIVATE)
    }

    private fun loadPrefs() {
        theme = prefs.getString("theme", "samsung") ?: "samsung"
        heightScale = prefs.getInt("height", 100) / 100f
        fontScale = prefs.getInt("font", 100) / 100f
        soundOn = prefs.getBoolean("sound", true)
        vibOn = prefs.getBoolean("vib", true)
    }

    override fun onCreateInputView(): View {
        loadPrefs()
        rebuild()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        caps = info != null && (info.inputType and EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0 && !arabic
        loadPrefs()
        rebuild()
    }

    private fun colors(): KeyTheme = when (theme) {
        "google" -> KeyTheme(0xFFECEEF2.toInt(), 0xFFFFFFFF.toInt(), 0xFFDCE1E8.toInt(), 0xFF1A1C1E.toInt(), 10f, true)
        "iphone" -> KeyTheme(0xFFD1D4DA.toInt(), 0xFFFFFFFF.toInt(), 0xFFAFB4BD.toInt(), 0xFF000000.toInt(), 8f, false)
        else -> KeyTheme(0xFF17181C.toInt(), 0xFF2E3038.toInt(), 0xFF23252C.toInt(), 0xFFFFFFFF.toInt(), 14f, false)
    }

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

    private fun rebuild() {
        val c = colors()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(c.container)
            setPadding(dp(6f), dp(8f), dp(6f), dp(10f))
        }

        val rows: List<List<String>> = when {
            symbols -> SYM_ROWS
            arabic -> AR_ROWS
            else -> EN_ROWS
        }

        rows.forEachIndexed { index, letters ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44f * heightScale))
                lp.topMargin = dp(6f)
                layoutParams = lp
            }
            if (index == 2) {
                row.addView(key("123", fn = true) { symbols = !symbols; rebuild() })
            }
            letters.forEach { ch ->
                val shown = if (!arabic && !symbols && caps) ch.uppercase() else ch
                row.addView(key(shown) { commit(shown); if (!arabic && caps) { caps = false; rebuild() } })
            }
            if (index == 2) {
                row.addView(key("⌫", fn = true) { backspace() })
            }
            root.addView(row)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44f * heightScale))
            lp.topMargin = dp(6f)
            layoutParams = lp
        }
        bottom.addView(key(if (arabic) "ع" else "EN", fn = true, flex = 1.8f) {
            arabic = !arabic; symbols = false; rebuild()
        })
        bottom.addView(key("مساحة", fn = true, flex = 5f) { commit(" ") })
        bottom.addView(key(if (symbols) "ABC" else "؟", fn = true, flex = 1.2f) {
            symbols = !symbols; rebuild()
        })
        bottom.addView(key("↵", fn = true, flex = 1.8f) { enter() })
        root.addView(bottom)
    }

    private fun key(label: String, fn: Boolean = false, flex: Float = 1f, onTap: () -> Unit): Button {
        val c = colors()
        val bg = GradientDrawable().apply {
            setColor(if (fn) c.fnKey else c.key)
            cornerRadius = dp(c.radius)
            if (c.stroke) {
                setStroke(dp(1f), 0xFFD5DAE0.toInt())
            }
        }
        return Button(this).apply {
            text = label
            textSize = if (label.length > 2) 12f * fontScale else 18f * fontScale
            setTextColor(c.text)
            setBackground(bg)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, flex)
            lp.marginEnd = dp(4f)
            layoutParams = lp
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { v.alpha = 0.65f; v.scaleY = 0.93f; v.scaleX = 0.95f }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 1f; v.scaleY = 1f; v.scaleX = 1f }
                }
                false
            }
            setOnClickListener {
                feedback()
                onTap()
            }
        }
    }

    private fun feedback() {
        if (soundOn) {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.6f)
        }
        if (vibOn) {
            val v = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") v.vibrate(12)
            }
        }
    }

    private fun commit(t: String) {
        currentInputConnection?.commitText(t, 1)
    }

    private fun backspace() {
        currentInputConnection?.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val ei = currentInputEditorInfo
        val action = ei?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private data class KeyTheme(
        val container: Int, val key: Int, val fnKey: Int,
        val text: Int, val radius: Float, val stroke: Boolean
    )
}
